/* %code "requires" block start */
#line 3 "calc_code_all.y"
/* CODE-REQUIRES */ 
/* %code "requires" block end */
#define DIGIT 257
#define LETTER 258
#define UMINUS 259
/* %code "provides" block start */
#line 4 "calc_code_all.y"
/* CODE-PROVIDES */ 
#line 6 "calc_code_all.y"
/* CODE-PROVIDES2 */ 
/* %code "provides" block end */
