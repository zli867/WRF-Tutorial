/* %code "requires" block start */
#line 1 "calc_code_requires.y"
/* CODE-REQUIRES */ 
#line 2 "calc_code_requires.y"
/* CODE-REQUIRES2 */ 
/* %code "requires" block end */
#define DIGIT 257
#define LETTER 258
#define UMINUS 259
