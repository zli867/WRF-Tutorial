#ifndef _calc_code_default__defines_h_
#define _calc_code_default__defines_h_

#define DIGIT 257
#define LETTER 258
#define UMINUS 259

#endif /* _calc_code_default__defines_h_ */
