#ifndef _err_syntax12__defines_h_
#define _err_syntax12__defines_h_

#define text 456

#endif /* _err_syntax12__defines_h_ */
