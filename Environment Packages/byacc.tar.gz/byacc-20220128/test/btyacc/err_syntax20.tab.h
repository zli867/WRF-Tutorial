#ifndef _err_syntax20__defines_h_
#define _err_syntax20__defines_h_

#define recur 257

#endif /* _err_syntax20__defines_h_ */
